#include<Windows.h>

int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE prevInstance, PSTR cmdLine,int showCmd)
{
	
	const int result=MessageBoxA(0,"i m awsome","awsome message box",MB_YESNOCANCEL);	//MeassageBoxA(HWND hWnd,LPCSTR ipText,LPCSTR ipCaption,UNIT utype)
										//HWND handle to window like there was handle to instance.A program refrences a window usinfg hwnd.its just anumber through which program identify the window and we can give 0/NULL if theres no window
										// the last parameter unit is for ok(0 bydefault puts ok) like if we want yes or no we can write MB_OKCANCEL etc
	
	switch(result)
	{
		case IDYES:
			MessageBoxA(0,"u clicked yes","note",0);
			break;
		case IDNO:
			MessageBoxA(0,"u clicked no","note",0);
			break;
			
	}
	
	return 0;
}
#include<Windows.h>

HWND windowHandle;

//step8
LRESULT CALLBACK Wndproc(HWND hwnd, UINT msg,WPARAM wParam,LPARAM lParam)   // we are sending message to window procedure
{
	switch(msg)
	{
		case WM_CLOSE:
			DestroyWindow(hwnd);
			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		
		default:
			return DefWindowProc(hwnd,msg,wParam,lParam);
	}
}

int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE previnstance,PSTR cmdLine,int showCmd)
{
	//step 1
	WNDCLASSEX wc;												//EX-extension and wc is class instance
	
	wc.cbSize=sizeof(WNDCLASSEX);     	// to set size of window
	wc.cbClsExtra=0; 					//extra size we want for class
	wc.cbWndExtra=0;					//extraq size for window
	wc.hIconSm=0;						// for small icon
	
	wc.hInstance=hInstance;
	wc.lpfnWndProc=Wndproc;      // its functiont to a pointer we have not created function wndproc till now
	wc.style=CS_HREDRAW | CS_VREDRAW;
	wc.lpszClassName="Sahil Class";  // for setting class name L converts text inti wide char UNICODE
	wc.lpszMenuName=0;  
	wc.hCursor= LoadCursor(0, IDC_ARROW);
	wc.hIcon= LoadIcon(0, IDI_APPLICATION);
	wc.hbrBackground=(HBRUSH)GetStockObject(BLACK_BRUSH);
	
	//step 2
	RegisterClassEx(&wc); 		// it will register and check if we have done any errors in step1
	
	//step 3
	windowHandle= CreateWindowEx(WS_EX_ACCEPTFILES,"Sahil Class","Window Name:",WS_OVERLAPPEDWINDOW | WS_VISIBLE,100,100,800,600,0,0,hInstance,0);
	
	//WC_EX_ACC- used to drag something into window it will accept
	//100,100 are initial coordinates of window
	//800,600 are height and width
	
	
	//step 4 
	if(windowHandle==0)
	{
		MessageBoxA(0,"creation of window failed","error message",0);
	}
	
	//step 5
	ShowWindow(windowHandle,showCmd);
	
	//step 6
	UpdateWindow(windowHandle);
	
	//step 7
	MSG msg;      // MSG is a class and msg is instance - whenever we do anything like shift window etc it is send as a message 

	int returnvalue=0;
	
	while((returnvalue=GetMessage(&msg,0,0,0))!=0)
	{
	
		TranslateMessage(&msg);
		DispatchMessage(&msg);
		
		
	}
	
	
	
	
	
	return msg.wParam;
}
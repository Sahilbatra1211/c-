#include<Windows.h>

int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE prevInstance, PSTR cmdLine,int showCmd)
{
	return 0;
}


// WINAPI-(it is a macro)it is a calling convention.for example it defines the order that parameter appear in stack
//HINSTANCE- it is handle to instance or we can say its not just a instance but a id to instance.therfore it 		
			//identifies the application to be loaded
//PSTR- is pointer to string and it is there if you want to add cmd commands while your program runs
//showcmd- show whether your program is fully maximised or minimised
//initialisation of string
#include<stdio.h>
int main()
{	char name[]={'a','b','c','\0'};
	char name2[]="abc";
		

}
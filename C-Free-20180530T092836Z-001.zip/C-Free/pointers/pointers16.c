//printing of string in different wasy
#include<stdio.h>
int main()
{
	char name[]="kinsman";
	int i=0;
	
	while(i<=7)  //while(name[i]!=0);
	{
		printf("%c",name[i]);
		i++;
	}
}
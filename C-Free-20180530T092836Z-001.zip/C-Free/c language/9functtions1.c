#include<stdio.h>
 int main()
 {
 	int a=0;
 	
 	printf("%d%d%d",a,a++,++a);   //in c caling convention of any function is from right to left
 }
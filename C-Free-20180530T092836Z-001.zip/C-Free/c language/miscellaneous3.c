#include<stdio.h>
int main()
{
	if(printf(""))     //if("hello") to if chalti else ni
	{
	printf("world");	
	}
	else{
		printf("sahil");
	}
	
}
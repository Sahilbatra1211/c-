//adding two nos and use of inputt
#include<stdio.h>
int main()
{
	int a,b,sum;
	printf("no1:");
	scanf("%d",&a); // a ek intteger h ye show kr ra h %d amd %f willl show ye ek flloat h
					// & is used in only input stream
	printf("\nno2;");
	scanf("%d",&b);
	
	printf("sum of two nos:");
	sum=a+b;
	printf("%d",sum);
}
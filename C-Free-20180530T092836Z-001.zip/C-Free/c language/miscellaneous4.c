//executing both if and else statement at same time
#include<stdio.h>
int main()
{ 
	if(printf("batra")==0)
	{
	printf("batra");	
	}
	else{
		printf("not battra");
	}
	
}
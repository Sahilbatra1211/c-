// if we would have initialized in the main then a junk value would have come

#include<stdio.h>

int a;

int main()
{
	printf("%d",a);
}
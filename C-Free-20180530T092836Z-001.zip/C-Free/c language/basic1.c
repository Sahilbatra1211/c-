// c is case sensitive
#include<stdio.h>

int main()
{
	printf("hello world");
	
}
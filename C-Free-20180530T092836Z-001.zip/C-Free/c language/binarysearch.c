//binary search
#include<stdio.h>
int main()
{
	
}
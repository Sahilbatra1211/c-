/*
int-2bytes
	int a;
	scanf("%d",&a);

float-4 bytes
	float b;
	scanf("%f%,&f)
	
double 4 bytes
		more precise than float
		double c;
		scanf("%e",&c);
char 1 byte
		char c;
		scanf("%c",&c);
		
ascii code- A-Z=65-90
			a-z=97-122
			0-10=48-57
			(c) The following statements would work

int a, b, c, d ;
a = b = c = 10 ;
However, the following statement would not work
int a = b = c = d = 10 ;					
	
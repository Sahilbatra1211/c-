#include<iostream>
using namespace std;

int main()
{
	string s="123456789";
	cout<<s;
}
#include<iostream>
using namespace std;

int main()
{
	string s1="0123456789";
	string s2="0123456789";
	if(s1!=s2)
	cout<<"sahil";
}
//pointers beahave totally differentt as strings. firstly  no need to make pointer array
#include<iostream.h>
#include<conio.h>
#include<stdio.h>

int main()
{
	char *p="word";
	cout<<p;
	cout<<"\n"<<*p;
	p++;
	cout<<"\n"<<p;
	
}
//how to print o??
//app 3
#include<iostream.h>
#include<conio.h>
#include<stdio.h>

int main()
{
	char *p="word";
	p="new";
	cout<<p; //puts(p)
}
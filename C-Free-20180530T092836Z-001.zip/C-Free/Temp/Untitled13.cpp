#include<iostream.h>
int main()
{
	int arr[6];
	
	cout<<a;
	cout<<"\n"<<a+1;
	cout<<"\n"<<&a;
	cout<<"\n"<<&(a+1);
}
//pattern 4
#include<iostream.h>
#include<conio.h>
#include<stdio.h>
int main()
{	
	for(int i=4;i>=1;i--)
	{	
		for(int j=4;j>=i;j--)
		{
			cout<<i;
		}
		cout<<"\n";
	}
}
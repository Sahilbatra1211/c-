//initialisation of character 
#include<stdio.h>
int main()
{ 
char name[]={'H','A','Z','/0'};
char name2[]={"Kinsman"};
int i;
while(i<=7)
{
	printf("%c",name[i]);
	i++;
}
	
}
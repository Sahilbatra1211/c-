//carefully see how to use printf and scanf
#include<stdio.h>
int main()
{
	int a=1,b=2,c=3;
	printf("%d%d%d",a+1,b+2,c+3);
	
	int e,f,g;
	printf("enter the no");
	scanf("%d%d%d",&e,&f,&g);
	
	
}
//largest no from given 5 no.
#include<iostream.h>
#include<conio.h>

int main()
{
	int i=0,a,b,c,d,e;
	
	cout<<"enter 5 no's";
	cin>>a>>b>>c>>d>>e;
	

		if(a>i)
		{
			i=a;
		}
		if(b>i)
		{
			i=b;
		}
		if(c>i)
		{
			i=c;
		}
		if(d>i)
		{
			i=d;
		}
		if(e>i)
		{
			i=e;
		}
	
	cout<<"max no"<<i;
}
#include<iostream.h>
#include<conio.h>
void scpy(char x[],char y[])
{
	int i;
	for(i=0;y[i]!='\0';i++)	
	{
		x[i]=y[i];
		
	}
	x[]
	
	
	puts(x);
}
int main()
{
	char a[100],b[100];
	gets(a);
	gets(b);
	scpy(a,b);
}
//pattern1
#include<iostream.h>
#include<conio.h>

int main()
{
	for(int i=0;i<4;i++)
	{
		for( int j=0;j<4;j++)
		{
			cout<<"*";
		}
		cout<<"\n";
	}
}
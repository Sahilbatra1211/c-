//finding a loop in a linklst by floyd's method 
#include<iostream.h>
#include<stdio.h>
#include<conio.h>

struct node
{
	node *next;
	int data;
	
};

node *end=NULL;
node *start;
node *start2;
node *end2=NULL;
node *head;

void push(int n)
{
	if(end==NULL)
	{	start=new node;
		start->data=n;
		start->next=NULL;
		end=start;
	}
	else{
		node *temp=new node;
		temp->data=n;
		temp->next=NULL;
		end->next=temp;
		end=temp;
	}	
}
void push1(int n2)
{
	if(end2==NULL)
	{	start2=new node;
		start2->data=n2;
		start2->next=NULL;
		end2=start2;
	}
	else{
		node *temp=new node;
		temp->data=n2;
		temp->next=NULL;
		end2->next=temp;
		end2=temp;
	}	
}

void mergingsortedlist()
{
	node *sorting;
	if(start2==NULL)
	sorting=start;
	
	if(start=NULL)
	sorting=start2;
	
	if(start2->data >= start->data)    //case1
	{
		sorting=start;
		start=sorting->next;
	}
	if(start2->data<=start->data)
	{
		sorting=start2;
		start2=sorting->next;
	}
	
	head=sorting;
	
	
	while(start && start2)     		//case2
	{
		if(start->data >= start2->data)
		{
			sorting->next=start2;
			sorting=start2;
			start2=sorting->next;
		}
		else 
		{
			sorting->next=start;
			sorting=start;
			start=sorting->next;
		}
	}
	if(start2==NULL)
	{
		sorting->next=start;
	}
	if(start==NULL)
	{
		sorting->next=start2;
	}
	
}
void displaymerge()
{
	node *temp=head;
	
	while(temp!=NULL)
	{
		cout<<"\t"<<temp->data;
		temp=temp->next;
	}
}

void display()
{
	node *temp=start;
	
	while(temp!=NULL)
	{
		cout<<"\n"<<temp->data;
		temp=temp->next;
	}
	
	node *temp2=start2;
	
	while(temp2!=NULL)
	{
		cout<<"\n"<<temp2->data;
		temp2=temp2->next;
	}
}





int main()
{

	push(10);
	push(50);
	push(70);
	push(90);
	push(100);
	push1(20);
	push1(30);
	push1(40);
	push1(50);
	push1(60);	
	display();
	cout<<"\n\n";
	mergingsortedlist();
	displaymerge();
}
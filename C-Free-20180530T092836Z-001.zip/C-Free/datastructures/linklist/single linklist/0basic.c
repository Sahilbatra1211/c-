//when we declare a variable like node * start in a func it gets freed as soon as function gets over
// memory is freed. the static variable declared is stored in stack.
// while when we allocate dynamically the variable does not get freed as it is stored in heap
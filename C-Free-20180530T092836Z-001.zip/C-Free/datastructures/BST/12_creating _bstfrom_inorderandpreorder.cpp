//creating binary tree from in order and preorder traversal

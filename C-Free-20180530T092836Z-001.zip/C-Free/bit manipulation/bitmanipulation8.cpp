//how to flip a no ex - 12-> 1100 to 0011
// we can do so by taking xor of 12 with (2^4-1) 
// similarly if we have to flip a no with 32  bit we can do so by taking its xor with (2^32-1)

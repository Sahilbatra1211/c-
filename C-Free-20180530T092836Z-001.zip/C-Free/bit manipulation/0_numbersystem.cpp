/*NUBER SYSTEM

binary no are those which are made of two digits 01 thats wgy binary
ocatal are made up of 8 that is 0-7
similarly hexadecimal from 16 that is 0-9 and A B C D E F 

1.DECIMAL TO BINARY CONVERSION
divide the no by 2 and note the remainders until the quotient becomes 0.then write the no's in reverse order.

2.DECIMAL TO OCTAL/BINARY/HEXADECIMAL/ANY
divide by that no by decimal no until the decimal no becomes 0 and arrange the remainder in reverse order
ex- in hexadecimal divide by 16
if remainder comes 10==A, 11==B,12==C and so on

3.any no to decimal
multiply each digit with 2^(n-1) from left to right and then add
similarly for octla 8^(n-1)

4.binary to octal
 group the binary no into 3 3
 ex- 110011
 write it as 110 011 
		      6   3
therfore 63 is the no
we made the group of three so that the number does not become more than 7

similarly coverting octal to bianry 63 just write the binary of each digit and covert

5.binary to hexadecimal
cut the string of binary into groups of 4 now and write their digits as did in octal
similar is reverse procedure of hexa to binary


// Abstract class- containing pure virtual functions 
/*
ex- virtual void fun()=0; this is pure virtual fun

if any class contains this then this is overided in derieved class and if we make a pointer of base class 
and adress of object of child class is put in that pointer and we call this overided function then child class function will be
implemneted only because of keyword virtual and this is also called late binding or runtime polymorphism*/ 
//ENCAPSULATION
/* wrapping of data into a single unit is called data abstraction
like member function and member variables are wrapped in single class and are also safe from outside world.
Encapsulation led to an important oops concept data hiding 
public,private and protected are part of data hiding*/ 
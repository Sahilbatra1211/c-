//ABSTRACTION
/* providing only essential information to the outside world.
Ex-like while using the objects we ignore the member function and
 the datatypes of the variables declared in the class */
 
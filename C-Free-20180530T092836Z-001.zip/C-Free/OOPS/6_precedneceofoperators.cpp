//precedence of operators
/*
postfix increment and decrement
prefix increment and decreamnt 
multiply
divide
remainder
addition 
subtraction
<<
>>
<
>
&&
||
?:
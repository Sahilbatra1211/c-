#include<iostream>
using namespace std;

template <class T,class M>
class pair{
	
	T a;
	M b;
	
	public:
	pair(T x,M y)
	{
		a=x;
		b=y;
	}
	
	
	
};

void main()
{
	data <int,float> d1(2,2.5);
}
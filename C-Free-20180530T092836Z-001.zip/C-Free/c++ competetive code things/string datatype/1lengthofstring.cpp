//finding lenght of string
#include <iostream>
using namespace std;

int main()
{
    string str = "C++ Programming";

    // you can also use str.length()
    cout << "String Length = " << str.size();

    return 0;
}